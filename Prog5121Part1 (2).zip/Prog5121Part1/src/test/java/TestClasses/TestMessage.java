/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestClasses;

import com.mycompany.prog5121part1.Message;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author growwithbella
 */
public class TestMessage {

    // Test Case 1 and 2 data from the brief
    private static final String RECIPIENT_1 = "+27718693002";
    private static final String TEXT_1 = "Hi Mike, can you join us for dinner tonight?";
    private static final String RECIPIENT_2 = "08575975889";
    private static final String TEXT_2 = "Hi Keegan, did you receive the payment?";

    @BeforeEach
    public void clearMessages() {
        Message.clearSentMessages();
    }

    @Test
    public void testMessageLengthSuccess() {
        Message m = new Message("0012345678", 0, RECIPIENT_1, TEXT_1);
        assertEquals("Message ready to send.", m.checkMessageLength());
    }

    @Test
    public void testMessageLengthFailure() {
        Message m = new Message("0012345678", 0, RECIPIENT_1, "a".repeat(260));
        assertEquals("Message exceeds 250 characters by 10; please reduce the size.",
                m.checkMessageLength());
    }

    @Test
    public void testRecipientSuccess() {
        Message m = new Message("0012345678", 0, RECIPIENT_1, TEXT_1);
        assertEquals("Cell phone number successfully captured.", m.checkRecipientCell());
    }

    @Test
    public void testRecipientFailure() {
        Message m = new Message("0087654321", 1, RECIPIENT_2, TEXT_2);
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
                m.checkRecipientCell());
    }

    @Test
    public void testMessageHashCase1() {
        Message m = new Message("0012345678", 0, RECIPIENT_1, TEXT_1);
        assertEquals("00:0:HITONIGHT", m.createMessageHash());
    }

    @Test
    public void testAllMessageHashesInLoop() {
        String[] ids = {"0012345678", "0087654321"};
        int[] numbers = {0, 1};
        String[] recipients = {RECIPIENT_1, RECIPIENT_2};
        String[] texts = {TEXT_1, TEXT_2};
        String[] expected = {"00:0:HITONIGHT", "00:1:HIPAYMENT"};

        for (int i = 0; i < ids.length; i++) {
            Message m = new Message(ids[i], numbers[i], recipients[i], texts[i]);
            assertEquals(expected[i], m.createMessageHash());
        }
    }

    @Test
    public void testMessageIDCreated() {
        Message m = new Message(0, RECIPIENT_1, TEXT_1);
        assertEquals("Message ID generated: " + m.getMessageID(), m.reportMessageID());
        assertTrue(m.checkMessageID());
    }

    @Test
    public void testMessageSentOptions() {
        Message m = new Message("0012345678", 0, RECIPIENT_1, TEXT_1);
        assertEquals("Message successfully sent.", m.SentMessage(1));
        assertEquals("Press 0 to delete the message.", m.SentMessage(2));
        assertEquals("Message successfully stored.", m.SentMessage(3));
    }

    @Test
    public void testTotalMessagesCounted() {
        new Message("0012345678", 0, RECIPIENT_1, TEXT_1).SentMessage(1);
        new Message("0087654321", 1, RECIPIENT_2, TEXT_2).SentMessage(2);
        assertEquals(1, Message.returnTotalMessages());
    }
}
