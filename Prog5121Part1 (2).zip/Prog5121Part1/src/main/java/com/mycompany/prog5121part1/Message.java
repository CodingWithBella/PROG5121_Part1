/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog5121part1;

import java.util.Random;
import java.util.regex.Pattern;
import java.util.ArrayList;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author growwithbella
 */
public class Message {

    private String messageID;
    private int messageNumber;
    private String recipient;
    private String messageText;

    // Normal use: ID is generated automatically
    public Message(int messageNumber, String recipient, String messageText) {
        this.messageID = generateMessageID();
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.messageText = messageText;
    }

    //For testing: supply a fixed ID
    public Message(String messageID, int messageNumber, String recipient, String messageText) {
        this.messageID = messageID;
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.messageText = messageText;
    }

    private String generateMessageID() {
        Random random = new Random();
        StringBuilder id = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            id.append(random.nextInt(10));
        }
        return id.toString();
    }

    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }

    public String getMessageID() {
        return messageID;
    }
    
    // Regex for a South African number: +27, then 9 digits (first digit 6, 7 or 8)
    private static final Pattern CELL_PATTERN = Pattern.compile("^\\+27[6-8][0-9]{8}$");

    public boolean isValidRecipient() {
        return recipient != null && CELL_PATTERN.matcher(recipient).matches();
    }
    
    public String checkRecipientCell() {
        if (isValidRecipient()) {
            return "Cell phone number successfully captured."; 
       }
        else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }
    
    public String getRecipient() {
        return recipient;
    }
    
    public String createMessageHash() {
        if (messageID == null || messageID.length() < 2
                || messageText == null || messageText.trim().isEmpty()) {
            return "";
        }
        
        String firstTwo = messageID.substring(0, 2);
        
        String[] words = messageText.trim().split("\\s+");
        String firstWord = cleanWord(words[0]);
        String lastWord = cleanWord(words[words.length - 1]);
        
        String hash = firstTwo + ":" + messageNumber + ":" + firstWord + lastWord;
        return hash.toUpperCase();
    }
    
    // Removes punctuation such as the "?" in "tonight?" or the "," in "Mike"
    private String cleanWord(String word) {
        return word.replaceAll("[^A-Za-z0-9]", "");
    }
    
    // Holds every message sent while the program is running
    private static final ArrayList<Message> sentMessages = new ArrayList<>();
    
    public String checkMessageLength() {
        int length = (messageText == null) ? 0 : messageText.length();
        if (length <= 250) {
            return "Message ready to send.";
        }
        return "Message exceeds 250 characters by " + (length - 250) + "; please reduce the size.";
    }
    
    public String reportMessageID() {
        return "Message ID generated: " + messageID;
    }
    
    public boolean isMessageLengthValid() {
        return messageText != null && messageText.length() <= 250;
    }

    public String getMessageDetails() {
        return "Message ID: " + messageID + "\n"
             + "Message Hash: " + createMessageHash() + "\n"
             + "Recipient: " + recipient + "\n"
             + "Message: " + messageText + "\n";
    }
    
    //Messages the user chose to store for later
    private static final ArrayList<Message> storedMessages = new ArrayList<>();
    private static final String JSON_FILE = "messages.json";
        
        public boolean storeMessage() {
            storedMessages.add(this);
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            
            try (FileWriter writer = new FileWriter(JSON_FILE)) {
                gson.toJson(storedMessages, writer);
                return true;
            } catch (IOException e) {
                storedMessages.remove(this);
                return false;
            }
        }
        
    public String SentMessage(int choice) {
         
        switch (choice) {
            case 1:
                sentMessages.add(this);
                return "Message successfully sent.";
            case 2:
                return "Press 0 to delete the message.";
            case 3:
                if (storeMessage()) {
                    return "Message successfully stored.";
                }
                return "Message could not be stored";
            default:
                return "Invalid option. Please choose 1 (Send), 2 (Disregard) or 3 (Store).";
        }
    }
    
    public static String printMessages() {
        StringBuilder sb = new StringBuilder ();
        for (Message m : sentMessages) {
            sb.append("Message ID: ").append(m.messageID).append("\n");
            sb.append("Message Hash: ").append(m.createMessageHash()).append("\n");
            sb.append("Recipient: ").append(m.recipient).append("\n");
            sb.append("Message: ").append(m.messageText).append("\n\n");
        }
        return sb.toString();
    }
    
    public static int returnTotalMessages() {
        return sentMessages.size();
    }
    
    // Lets unit tests start from a clean slate
    public static void clearSentMessages() {
        sentMessages.clear();
    }
}


