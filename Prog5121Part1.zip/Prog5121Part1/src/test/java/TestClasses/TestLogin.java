/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package TestClasses;

import com.mycompany.prog5121part1.Login;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author growwithbella
 */
public class TestLogin {
    
    @Test
    public void testUsernameCorrectlyFormatted() {
        Login user = new Login("bel_", "Bella123!", "+27831111111");

        assertEquals(true, user.checkUserName());
    }

    @Test
    public void testUsernameIncorrectlyFormatted() {
        Login user = new Login("bella123", "Bella123!", "+27831111111");

        assertEquals(false, user.checkUserName());
    }

    @Test
    public void testPasswordMeetsComplexityRequirements() {
        Login user = new Login("bel_", "Bella123!", "+27831111111");

        assertEquals(true, user.checkPasswordComplexity("Bella123!"));
    }

    @Test
    public void testPasswordDoesNotMeetComplexityRequirements() {
        Login user = new Login("bel_", "password", "+27831111111");

        assertEquals(false, user.checkPasswordComplexity("password"));
    }

    @Test
    public void testCellPhoneCorrectlyFormatted() {
        Login user = new Login("bel_", "Bella123!", "+27831111111");

        assertEquals(true, user.checkCellPhoneNumber());
    }

    @Test
    public void testCellPhoneIncorrectlyFormatted() {
        Login user = new Login("bel_", "Bella123!", "0831111111");

        assertEquals(false, user.checkCellPhoneNumber());
    }

    @Test
    public void testLoginSuccessful() {
        Login user = new Login("bel_", "Bella123!", "+27831111111");

        assertTrue(user.loginUser("Bella123!"));
    }

    @Test
    public void testLoginFailed() {
        Login user = new Login("bel_", "Bella123!", "+27831111111");

        assertFalse(user.loginUser("WrongPassword123!"));
    }

    @Test
    public void testUsernameCorrectlyFormattedTrue() {
        Login user = new Login("bel_", "Bella123!", "+27831111111");

        assertTrue(user.checkUserName());
    }

    @Test
    public void testUsernameIncorrectlyFormattedFalse() {
        Login user = new Login("bella123", "Bella123!", "+27831111111");

        assertFalse(user.checkUserName());
    }

    @Test
    public void testPasswordMeetsComplexityTrue() {
        Login user = new Login("bel_", "Bella123!", "+27831111111");

        assertTrue(user.checkPasswordComplexity("Bella123!"));
    }

    @Test
    public void testPasswordDoesNotMeetComplexityFalse() {
        Login user = new Login("bel_", "Bella123!", "+27811111111");

        assertFalse(user.checkPasswordComplexity("password"));
    }

    @Test
    public void testCellPhoneCorrectlyFormattedTrue() {
        Login user = new Login("bel_", "Bella123!", "+27831111111");

        assertTrue(user.checkCellPhoneNumber());
    }

    @Test
    public void testCellPhoneIncorrectlyFormattedFalse() {
        Login user = new Login("bel_", "Bella123!", "0831111111");

        assertFalse(user.checkCellPhoneNumber());
    }
}
