/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog5121part1;

import java.util.Random;
import java.util.regex.Pattern;
import java.util.ArrayList;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.FileWriter;
import java.io.IOException;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import java.io.File;
import java.io.FileReader;
import java.lang.reflect.Type;

/**
 *
 * @author growwithbella
 */
public class Message {

    private String messageID;
    private int messageNumber;
    private String recipient;
    private String messageText;
    private String sender;

    // Normal use: ID is generated automatically
    public Message(int messageNumber, String recipient, String messageText) {
        this.messageID = generateMessageID();
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.messageText = messageText;
    }

    //For testing: supply a fixed ID
    public Message(String messageID, int messageNumber, String recipient, String messageText) {
        this.messageID = messageID;
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.messageText = messageText;
    }

    private String generateMessageID() {
        Random random = new Random();
        StringBuilder id = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            id.append(random.nextInt(10));
        }
        return id.toString();
    }

    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }

    public String getMessageID() {
        return messageID;
    }
    
        public void setSender(String sender) {
        this.sender = sender;
    }

    public String getSender() {
        return sender;
    }

    // Older saved messages have no sender, so show "Unknown" instead of "null"
    private String displaySender() {
        return (sender == null || sender.trim().isEmpty()) ? "Unknown" : sender;
    }

    // Item (a): the sender and recipient of every stored message
    public static String displaySenderAndRecipient() {
        if (storedMessages.isEmpty()) {
            return "There are no stored messages.";
        }
        StringBuilder sb = new StringBuilder();
        for (Message m : storedMessages) {
            sb.append("Sender: ").append(m.displaySender())
              .append(" | Recipient: ").append(m.recipient).append("\n");
        }
        return sb.toString();
    }

    // Item (b): the longest stored message
    public static String longestStoredMessage() {
        Message longest = null;
        for (Message m : storedMessages) {
            if (m.messageText == null) {
                continue;
            }
            if (longest == null || m.messageText.length() > longest.messageText.length()) {
                longest = m;
            }
        }
        if (longest == null) {
            return "There are no stored messages.";
        }
        return longest.messageText;
    }
    
    // All messages that were sent or stored (disregarded ones are left out)
    private static ArrayList<Message> sentAndStored() {
        ArrayList<Message> all = new ArrayList<>(sentMessages);
        for (Message m : storedMessages) {
            if (!all.contains(m)) {
                all.add(m);
            }
        }
        return all;
    }

    // Item (c): find a message by its ID and show the recipient and message
    public static String searchByMessageID(String id) {
        if (id != null) {
            for (Message m : sentAndStored()) {
                if (id.trim().equals(m.messageID)) {
                    return "Recipient: " + m.recipient + " | Message: " + m.messageText;
                }
            }
        }
        return "No message found with that message ID.";
    }

    // Item (d): every message text sent or stored for one recipient
    public static ArrayList<String> searchByRecipient(String recipient) {
        ArrayList<String> results = new ArrayList<>();
        if (recipient != null) {
            for (Message m : sentAndStored()) {
                if (recipient.trim().equals(m.recipient)) {
                    results.add(m.messageText);
                }
            }
        }
        return results;
    }
    
    // Item (e): delete a stored message using its hash
    public static String deleteByHash(String hash) {
        if (hash != null) {
            for (Message m : storedMessages) {
                if (hash.trim().equalsIgnoreCase(m.createMessageHash())) {
                    storedMessages.remove(m);
                    saveStoredMessages();
                    return "Message: \"" + withoutFinalFullStop(m.messageText) + "\" successfully deleted.";
                }
            }
        }
        return "No stored message found with that message hash.";
    }

    private static String withoutFinalFullStop(String text) {
        if (text != null && text.endsWith(".")) {
            return text.substring(0, text.length() - 1);
        }
        return text;
    }

    // Item (f): a report with the full details of every message in a list
    private static String buildReport(ArrayList<Message> list, String kind) {
        if (list.isEmpty()) {
            return "There are no " + kind + " messages.";
        }
        StringBuilder sb = new StringBuilder();
        for (Message m : list) {
            sb.append("Message ID: ").append(m.messageID).append("\n");
            sb.append("Message Hash: ").append(m.createMessageHash()).append("\n");
            sb.append("Sender: ").append(m.displaySender()).append("\n");
            sb.append("Recipient: ").append(m.recipient).append("\n");
            sb.append("Message: ").append(m.messageText).append("\n\n");
        }
        return sb.toString();
    }

    public static String reportStoredMessages() {
        return buildReport(storedMessages, "stored");
    }

    public static String reportSentMessages() {
        return buildReport(sentMessages, "sent");
    }
    
    // Regex for a South African number: +27, then 9 digits (first digit 6, 7 or 8)
    private static final Pattern CELL_PATTERN = Pattern.compile("^\\+27[6-8][0-9]{8}$");

    public boolean isValidRecipient() {
        return recipient != null && CELL_PATTERN.matcher(recipient).matches();
    }
    
    public String checkRecipientCell() {
        if (isValidRecipient()) {
            return "Cell phone number successfully captured."; 
       }
        else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }
    
    public String getRecipient() {
        return recipient;
    }
    
    public String createMessageHash() {
        if (messageID == null || messageID.length() < 2
                || messageText == null || messageText.trim().isEmpty()) {
            return "";
        }
        
        String firstTwo = messageID.substring(0, 2);
        
        String[] words = messageText.trim().split("\\s+");
        String firstWord = cleanWord(words[0]);
        String lastWord = cleanWord(words[words.length - 1]);
        
        String hash = firstTwo + ":" + messageNumber + ":" + firstWord + lastWord;
        return hash.toUpperCase();
    }
    
    // Gson needs this to build an empty Message before filling in the saved fields
    private Message() {
    }
    
    // Removes punctuation such as the "?" in "tonight?" or the "," in "Mike"
    private String cleanWord(String word) {
        return word.replaceAll("[^A-Za-z0-9]", "");
    }
    
    // Holds every message sent while the program is running
    private static final ArrayList<Message> sentMessages = new ArrayList<>();
    
    public String checkMessageLength() {
        int length = (messageText == null) ? 0 : messageText.length();
        if (length <= 250) {
            return "Message ready to send.";
        }
        return "Message exceeds 250 characters by " + (length - 250) + "; please reduce the size.";
    }
    
    public String reportMessageID() {
        return "Message ID generated: " + messageID;
    }
    
    public boolean isMessageLengthValid() {
        return messageText != null && messageText.length() <= 250;
    }

    public String getMessageDetails() {
        return "Message ID: " + messageID + "\n"
             + "Message Hash: " + createMessageHash() + "\n"
             + "Recipient: " + recipient + "\n"
             + "Message: " + messageText + "\n";
    }
    
    //Messages the user chose to store for later
    private static final ArrayList<Message> storedMessages = new ArrayList<>();
    private static String jsonFile = "messages.json";
    private static final ArrayList<Message> disregardedMessages = new ArrayList<>();
    private static final ArrayList<String> messageHashes = new ArrayList<>();
    private static final ArrayList<String> messageIDs = new ArrayList<>();
    
    public boolean storeMessage() {
        storedMessages.add(this);
        if (saveStoredMessages()) {
            return true;
        }
        storedMessages.remove(this);
        return false;
    }

    // Writes the whole stored-messages array to the JSON file
    public static boolean saveStoredMessages() {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        try (FileWriter writer = new FileWriter(jsonFile)) {
            gson.toJson(storedMessages, writer);
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    // Reads the JSON file back into the stored-messages array
    public static boolean loadStoredMessages() {
        File file = new File(jsonFile);
        if (!file.exists()) {
            return false;
        }
        try (FileReader reader = new FileReader(file)) {
            Type listType = new TypeToken<ArrayList<Message>>() { }.getType();
            ArrayList<Message> loaded = new Gson().fromJson(reader, listType);
            storedMessages.clear();
            if (loaded != null) {
                for (Message m : loaded) {
                    if (m != null && m.messageID != null) {
                        storedMessages.add(m);
                        m.recordIdentifiers();
                    }
                }
            }
            return true;
        } catch (IOException | JsonSyntaxException e) {
            return false;
        }
    }

    // Lets the unit tests use a throwaway file instead of the real one
    public static void setJsonFile(String path) {
        jsonFile = path;
    }
        
    public String SentMessage(int choice) {
         
        switch (choice) {
            case 1:
                recordIdentifiers();
                sentMessages.add(this);
                return "Message successfully sent.";
            case 2:
                recordIdentifiers();
                disregardedMessages.add(this);
                return "Press 0 to delete the message.";
            case 3:
                recordIdentifiers();
                if (storeMessage()) {
                    return "Message successfully stored.";
                }
                return "Message could not be stored";
            default:
                return "Invalid option. Please choose 1 (Send), 2 (Disregard) or 3 (Store).";
        }
    }
    
    public static String printMessages() {
        StringBuilder sb = new StringBuilder ();
        for (Message m : sentMessages) {
            sb.append("Message ID: ").append(m.messageID).append("\n");
            sb.append("Message Hash: ").append(m.createMessageHash()).append("\n");
            sb.append("Recipient: ").append(m.recipient).append("\n");
            sb.append("Message: ").append(m.messageText).append("\n\n");
        }
        return sb.toString();
    }
    
    public static int returnTotalMessages() {
        return sentMessages.size();
    }
    
    // Lets unit tests start from a clean slate
    public static void clearSentMessages() {
        sentMessages.clear();
    }
    
    private void recordIdentifiers() {
        if (!messageIDs.contains(messageID)) {
            messageIDs.add(messageID);
            messageHashes.add(createMessageHash());
        }
    }
    
    public String getMessageText() {
        return messageText;
    }
    
    // These return copies, so other code can read the arrays but not change them by accident
    public static ArrayList<Message> getSentMessages() {
        return new ArrayList<>(sentMessages);
    }
    
    public static ArrayList<Message> getDisregardedMessages() {
        return new ArrayList<>(disregardedMessages);
    }
    
    public static ArrayList<Message> getStoredMessages() {
        return new ArrayList<>(storedMessages);
    }

    public static ArrayList<String> getMessageHashes() {
        return new ArrayList<>(messageHashes);
    }

    public static ArrayList<String> getMessageIDs() {
        return new ArrayList<>(messageIDs);
    }
    
    // Empties all five arrays (used by the unit tests)
    public static void clearAll() {
        sentMessages.clear();
        disregardedMessages.clear();
        storedMessages.clear();
        messageHashes.clear();
        messageIDs.clear();
    }
}


