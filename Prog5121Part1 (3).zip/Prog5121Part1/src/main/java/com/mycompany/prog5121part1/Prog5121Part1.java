/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prog5121part1;
import java.util.Scanner;
import java.util.ArrayList;


/**
 *
 * @author growwithbella
 */
public class Prog5121Part1 {
    
    private static final Scanner scanner = new Scanner(System.in);
    private static Login registeredUser = null;

    public static void main(String[] args) {
        Message.loadStoredMessages();

         
        
        System.out.println("PROGRAM HAS STARTED!");
        System.out.println("\nWelcome to our Chat App 2026!");

        boolean running = true;
        while (running) {
            System.out.println("\n===== MAIN MENU =====");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");

            switch (readInt()) {
                case 1:
                    handleRegistration();
                    break;
                case 2:
                    if (handleLogin()) {
                        startQuickChat();
                    }
                    break;
                case 3:
                    running = false;
                    System.out.println("Goodbye!");
                    break;
                default:
                    System.out.println("Invalid option. Please enter 1, 2 or 3.");
            }
        }
    }

    private static void handleRegistration() {
        System.out.println("\n===== REGISTRATION =====");
        System.out.print("Enter first name: ");
        String firstName = scanner.nextLine().trim();
        System.out.print("Enter last name: ");
        String lastName = scanner.nextLine().trim();
        System.out.print("Enter username: ");
        String username = scanner.nextLine().trim();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        System.out.print("Enter South African cellphone number (e.g. +27831111111): ");
        String phone = scanner.nextLine().trim();

        Login candidate = new Login(firstName, lastName, username, password, phone);

        if (!candidate.checkCellPhoneNumber()) {
            System.out.println("Cell phone number incorrectly formatted or does not contain international code.");
            return;
        }
        System.out.println("Cell phone number successfully added.");

        System.out.println(candidate.registerUser());
        if (!candidate.checkUserName() || !candidate.checkPasswordComplexity()) {
            return;
        }

        registeredUser = candidate;
    }

    private static boolean handleLogin() {
        if (registeredUser == null) {
            System.out.println("No user is registered yet. Please register first.");
            return false;
        }

        System.out.println("\n===== LOGIN =====");
        System.out.print("Enter username: ");
        String username = scanner.nextLine().trim();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        boolean success = registeredUser.loginUser(username, password);
        System.out.println(registeredUser.returnLoginStatus(success));
        return success;
    }

    private static void startQuickChat() {
        System.out.println("\nWelcome to QuickChat.");

        int totalAllowed = 0;
        while (totalAllowed <= 0) {
            System.out.print("How many messages would you like to enter? ");
            totalAllowed = readInt();
            if (totalAllowed <= 0) {
                System.out.println("Please enter a whole number greater than 0.");
            }
        }

        int entered = 0;
        boolean chatting = true;

        while (chatting) {
            System.out.println("\n===== QUICKCHAT MENU =====");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.println("4) Stored Messages");
            System.out.print("Choose an option: ");

            switch (readInt()) {
                case 1:
                    if (entered >= totalAllowed) {
                        System.out.println("You have already entered all " + totalAllowed + " messages.");
                    } else {
                        processMessage(entered);
                        entered++;
                        if (entered == totalAllowed) {
                            System.out.println("Total messages sent: " + Message.returnTotalMessages());
                        }
                    }
                    break;
                case 2:
                    System.out.println("Coming Soon.");
                    break;
                case 3:
                    System.out.println("Total messages sent: " + Message.returnTotalMessages());
                    chatting = false;
                    break;
                case 4:
                    storedMessagesMenu();
                    break;
                default:
                    System.out.println("Invalid option. Please enter 1, 2, 3 or 4.");
            }
        }
    }
    
    private static void storedMessagesMenu() {
        boolean inMenu = true;
        while (inMenu) {
            System.out.println("\n===== STORED MESSAGES =====");
            System.out.println("1) Display the sender and recipient of all stored messages");
            System.out.println("2) Display the longest stored message");
            System.out.println("3) Search for a message ID");
            System.out.println("4) Search for all messages to a recipient");
            System.out.println("5) Delete a message using its hash");
            System.out.println("6) Display a report of all stored messages");
            System.out.println("7) Back");
            System.out.print("Choose an option: ");

            switch (readInt()) {
                case 1:
                    System.out.println(Message.displaySenderAndRecipient());
                    break;
                case 2:
                    System.out.println(Message.longestStoredMessage());
                    break;
                case 3:
                    System.out.print("Enter the message ID: ");
                    System.out.println(Message.searchByMessageID(scanner.nextLine()));
                    break;
                case 4:
                    System.out.print("Enter the recipient's cell number: ");
                    printRecipientResults(scanner.nextLine());
                    break;
                case 5:
                    System.out.print("Enter the message hash: ");
                    System.out.println(Message.deleteByHash(scanner.nextLine()));
                    break;
                case 6:
                    System.out.println(Message.reportStoredMessages());
                    break;
                case 7:
                    inMenu = false;
                    break;
                default:
                    System.out.println("Invalid option. Please enter a number from 1 to 7.");
            }
        }
    }

    private static void printRecipientResults(String recipient) {
        ArrayList<String> results = Message.searchByRecipient(recipient);
        if (results.isEmpty()) {
            System.out.println("No messages found for that recipient.");
            return;
        }
        for (String text : results) {
            System.out.println(text);
        }
    }

    private static void processMessage(int messageNumber) {
        Message message = readMessage(messageNumber);
        message.setSender(registeredUser.getFullName());
        System.out.println(message.reportMessageID());

        int choice = 0;
        while (choice < 1 || choice > 3) {
            System.out.println("\nWhat would you like to do with this message?");
            System.out.println("1) Send Message");
            System.out.println("2) Disregard Message");
            System.out.println("3) Store Message to send later");
            System.out.print("Choose an option: ");
            choice = readInt();
            if (choice < 1 || choice > 3) {
                System.out.println("Please choose 1, 2 or 3.");
            }
        }

        System.out.println(message.SentMessage(choice));

        if (choice == 1) {
            System.out.println("\n" + message.getMessageDetails());
        } else if (choice == 2) {
            if (scanner.nextLine().trim().equals("0")) {
                System.out.println("Message deleted.");
            }
        }
    }

    private static Message readMessage(int messageNumber) {
        String recipient;
        while (true) {
            System.out.print("Enter recipient cell number (e.g. +27718693002): ");
            recipient = scanner.nextLine().trim();
            Message probe = new Message(messageNumber, recipient, "");
            System.out.println(probe.checkRecipientCell());
            if (probe.isValidRecipient()) {
                break;
            }
        }

        while (true) {
            System.out.print("Enter your message (max 250 characters): ");
            String text = scanner.nextLine();
            if (text.trim().isEmpty()) {
                System.out.println("The message cannot be empty.");
                continue;
            }
            Message candidate = new Message(messageNumber, recipient, text);
            System.out.println(candidate.checkMessageLength());
            if (candidate.isMessageLengthValid()) {
                return candidate;
            }
        }
    }
    
    // Reads a whole line and converts it, so typing letters can't crash the program
    private static int readInt() {
        String line = scanner.nextLine().trim();
        try {
            return Integer.parseInt(line);
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}